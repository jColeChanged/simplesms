from distutils.core import setup
setup(name='simplesms',
      version='1.0',
      py_modules=['simplesms'],
      )
